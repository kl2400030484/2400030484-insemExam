// My theme toggle JavaScript!
// This is my first JavaScript project

// Variable to track if we're in dark mode or not
var isDark = false;

// Function to change the theme
function changeTheme() {
    // Get the body element
    var body = document.body;
    var themeDisplay = document.getElementById('themeDisplay');
    var button = document.getElementById('themeButton');
    
    // Check if we're currently dark
    if (isDark) {
        // Change to light theme
        body.className = ''; // Remove dark class
        themeDisplay.innerHTML = 'light';
        button.innerHTML = 'Switch to Dark';
        isDark = false;
        
        // Would save to browser storage in real app
        
    } else {
        // Change to dark theme
        body.className = 'dark'; // Add dark class
        themeDisplay.innerHTML = 'dark';
        button.innerHTML = 'Switch to Light';
        isDark = true;
        
        // Would save to browser storage in real app
    }
    
    console.log('Theme changed to: ' + (isDark ? 'dark' : 'light'));
}

// Function that runs when page loads
function setupPage() {
    // Get the button
    var button = document.getElementById('themeButton');
    
    // Add click event to button
    button.onclick = changeTheme;
    
    // Would load saved theme from browser storage in real app
    
    console.log('Page setup complete!');
}

// Wait for page to load then setup
window.onload = setupPage;

// Alternative way to wait for page load (learned this online)
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded!');
});