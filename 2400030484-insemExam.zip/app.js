/**
 * React-style Theme Toggle Application
 * Project: 2400030484-insemExam
 * 
 * This demonstrates the same functionality as the React version,
 * adapted to work in a browser environment without persistent storage.
 */

// Theme state management
let currentTheme = 'light';

// Storage key (for reference - would be used in React version)
const STORAGE_KEY = 'student-theme-preference';

/**
 * Get initial theme preference
 * In React version, this would check browser storage first
 */
function getInitialTheme() {
  // In a real React app, we would check storage here:
  // try {
  //   const saved = storage.getItem(STORAGE_KEY);
  //   if (saved === 'light' || saved === 'dark') return saved;
  // } catch (e) {
  //   console.warn('Could not read theme preference:', e);
  // }

  // Fallback to system preference
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  return 'light';
}

/**
 * Apply theme to document and update UI
 * This mirrors the useEffect in the React version
 */
function applyTheme(theme) {
  const root = document.documentElement;
  const toggleBtn = document.getElementById('theme-toggle');
  const currentThemeSpan = document.getElementById('current-theme');
  
  // Set data attribute for CSS styling
  root.setAttribute('data-theme', theme);
  
  // Update button state and text
  const isDark = theme === 'dark';
  toggleBtn.setAttribute('aria-pressed', isDark.toString());
  toggleBtn.textContent = isDark ? '🌙 Dark' : '☀️ Light';
  toggleBtn.title = `Switch to ${isDark ? 'light' : 'dark'} theme`;
  
  // Update current theme display
  currentThemeSpan.textContent = theme;
  
  // In React version, we would save to storage here:
  // try {
  //   storage.setItem(STORAGE_KEY, theme);
  // } catch (e) {
  //   console.warn('Could not save theme preference:', e);
  // }
  
  console.log(`Theme applied: ${theme}`);
}

/**
 * Toggle theme function
 * This mirrors the toggle function in the React App component
 */
function toggleTheme() {
  currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
  applyTheme(currentTheme);
}

/**
 * Initialize application
 * This mirrors the React component initialization
 */
function initializeApp() {
  // Get initial theme (would check storage in React version)
  currentTheme = getInitialTheme();
  
  // Apply initial theme
  applyTheme(currentTheme);
  
  // Set up event listener for theme toggle
  const toggleBtn = document.getElementById('theme-toggle');
  toggleBtn.addEventListener('click', toggleTheme);
  
  // Add keyboard support
  toggleBtn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      toggleTheme();
    }
  });
  
  // Listen for system theme changes (like in React version)
  if (window.matchMedia) {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    mediaQuery.addEventListener('change', (e) => {
      console.log('System theme changed:', e.matches ? 'dark' : 'light');
      // In a full React implementation, you might want to sync with system changes
      // when no user preference is stored
    });
  }
  
  // Remove loading state
  document.body.classList.remove('loading');
  document.body.classList.add('loaded');
  
  console.log('Theme toggle app initialized');
  console.log('Initial theme:', currentTheme);
}

/*
 * React Component Structure (for reference)
 * 
 * This application demonstrates the following React patterns:
 * 
 * App Component:
 * - Uses useState for theme state management
 * - Uses useEffect for DOM manipulation and storage
 * - Implements toggle function for theme switching
 * 
 * ThemeToggle Component:
 * - Receives theme and onToggle as props
 * - Uses aria-pressed for accessibility
 * - Shows appropriate icon and text for current theme
 */

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApp);
} else {
  initializeApp();
}

// Add loading state initially
document.body.classList.add('loading');

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    toggleTheme,
    applyTheme,
    getInitialTheme,
    currentTheme
  };
}